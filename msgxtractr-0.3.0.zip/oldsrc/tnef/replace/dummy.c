/* 
 * dummy function to ensure that libreplace.a is never empty since
 * that is non-portable.
 */
void
___dummy___()
{}
